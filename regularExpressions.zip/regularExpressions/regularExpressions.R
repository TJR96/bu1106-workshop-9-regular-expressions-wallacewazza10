#Question 1
#Think of different formats of writing down prices in Pounds and Euros and write down your answer to this question (one per line).

#Example: €149.95, £150, ...
#149.95 pounds
#150 euros
#one hundred and fourty-nine and ninety pence
#one hundred and fifty euros

#Question 2
#Find a regular expression that will match the prices in Pounds and Euros (from your previous question).
#If you cannot match all try to match as many as possible. If you can't match all, don't change Question 1 by pretending you came up with fewer price formats, but you matched them all. It's better if you come up with lots of formats you can't match than if you only come up with very few formats, but you can match all.

#using the grep function to match patterns with € or £
grep(pattern = "€||£", x = x)

#Question 3
#Find a regular expression that will only match prices under £150 and under €150.
grep(pattern <= "£150" || "€150" , x = x)

#Question 4
#Find a regular expression that will match a typical UCLan email address.
grep(pattern <= "@UCLan" , x = x)